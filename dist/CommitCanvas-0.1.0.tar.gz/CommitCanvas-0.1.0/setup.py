# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['commitcanvas']

package_data = \
{'': ['*'],
 'commitcanvas': ['model/*',
                  'model/ner/*',
                  'model/parser/*',
                  'model/tagger/*',
                  'model/vocab/*',
                  'spacy_training_data/*']}

install_requires = \
['en>=0.0.1,<0.0.2',
 'en_core_web_sm @ '
 'https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-2.3.0/en_core_web_sm-2.3.0.tar.gz',
 'pre-commit>=2.5.1,<3.0.0',
 'spacy>=2.3.2,<3.0.0']

entry_points = \
{'console_scripts': ['commitcanvas = commitcanvas.__main__:main']}

setup_kwargs = {
    'name': 'commitcanvas',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'bagashvilit',
    'author_email': 'bagashvilit@allegheny.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
