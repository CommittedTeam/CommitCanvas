"""Command line inferface."""
# pylint: disable = import-error
#import typer

def main():
    """Demo function."""
    print("Hello World")


if __name__ == "__main__":
    main()

# APP = typer.Typer()
#
#
# @APP.command()
# def hello(message: str):
#     """Demo function."""
#     print(message)
#
#
# def main():
#     """Start execution of the program."""
#     APP()
